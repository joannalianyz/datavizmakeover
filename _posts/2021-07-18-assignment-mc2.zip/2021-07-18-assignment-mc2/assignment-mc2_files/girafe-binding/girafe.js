HTMLWidgets.widget({
  name: 'girafe',
  type: 'output',
  factory: ggiraphjs.factory(HTMLWidgets.shinyMode)
});
